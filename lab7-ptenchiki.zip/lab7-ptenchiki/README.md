# Team Ptenchiki:
1. Artyom Aralov
2. Artur Aralov
3. Sergei Ku�t�enko

## Homework 1:
<[Homework 1](https://bitbucket.org/ArtyomkaQQ/lab7-ptenchiki/wiki/Homework%201)> 

## Homework 2:
<[Homework 2](https://bitbucket.org/ArtyomkaQQ/lab7-ptenchiki/wiki/Homework%202)>

## Homework 3:
<[Homework 3](https://bitbucket.org/ArtyomkaQQ/lab7-ptenchiki/wiki/Homework%203)>

## Homework 4:
<[Homework 4](https://bitbucket.org/ArtyomkaQQ/lab7-ptenchiki/wiki/Homework%204)>

## Homework 5:
<[Homework 5](https://bitbucket.org/ArtyomkaQQ/lab7-ptenchiki/wiki/Homework%205)>

## Homework 6:
<[Homework 6](https://bitbucket.org/ArtyomkaQQ/lab7-ptenchiki/wiki/Homework%206)>

## Homework 7:
<[Homework 7](https://bitbucket.org/ArtyomkaQQ/lab7-ptenchiki/wiki/Homework%207)>

We encourage you to use [markdown syntax](https://confluence.atlassian.com/bitbucketserver/markdown-syntax-guide-776639995.html)